# Modern-Web-Developer-Starter-Kit


So I built this for all the new web developers... My Goal is to save you time from the bullsh*t of spending hours looking for ways to speed up your learning. Sometimes all we want to do is just code.
(if you are coming from my  [youtube channel CodingPhase ](https://www.youtube.com/channel/UC46wWUso9H5KPQcoL9iE3Ug) I will base all my tutorials from this starter kit)

I broke it down in simple steps to get you going.

**Steps**
---------

**Download or Pull This Repo**
	Top of this page you can see where it says clone or download

 **Install Node**
	https://nodejs.org/en/

**Install Yarn**
	https://yarnpkg.com/en/docs/install

**Download Atom**
	https://atom.io/

**Install all the atom packages that I own**

On the root of this project run on your terminal

    apm install --packages-file atom-package-list.txt

 **Install all the node packages**
On the root of this project run on your terminal


    yarn


**Start the server**

    npm start
